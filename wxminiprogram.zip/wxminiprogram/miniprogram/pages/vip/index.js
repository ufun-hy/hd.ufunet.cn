const app = getApp()
let rewardedVideoAd = null
let timer = null
Page({
  data:{
    user: {
      userid:'',
      openid: '',
    },
    imgBaseUrl:app.globalData.baseUrl + 'static/images/sys/vip',
    endtime:0,
    timeLeft:{h: '00',m: '00',s: '00'},
    rewardhour:app.globalData.rewardhour,
  },
  onLoad: function(options) {
    const self = this
    let params = decodeURIComponent(options.params);
    if(params != ''){
      params = JSON.parse(params) || {}
      if(params.userid && params.openid){
        self.setData({user:params});
      }
    }
    wx.hideShareMenu();
    wx.setNavigationBarTitle({
      title: "看视频免费开通会员"
    });
    if (wx.createRewardedVideoAd && app.globalData.rewardedadid != '') {
      rewardedVideoAd = wx.createRewardedVideoAd({ adUnitId: app.globalData.rewardedadid })
      rewardedVideoAd.onLoad(() => {})
      rewardedVideoAd.onError((err) => {
        wx.showToast({
          title: "视频加载失败",
          duration: 2000,
          icon: 'error'
        })
      })
      rewardedVideoAd.onClose((res) => {
        if (res && res.isEnded) {
          self.saveviprecord();
          wx.showToast({
            title: (self.data.endtime > 0 ? `您的会员已延长${self.data.rewardhour}小时` : `您已获得${self.data.rewardhour}小时会员`),
            duration: 3000,
            icon: 'success'
          });
        }
      })
    }
    app.getViprecord(function(time){
      if(time > 0){
        var now = new Date().getTime();
        var end = +new Date(time * 1000);
        if(end - now <= 0){
            time = 0;
        }
      }
      self.setData({endtime:time});
      app.globalData.adendtime = time;
      self.startDjs('1')
    })
  },
  onUnload: function() {
    this.clearDjs()
  },
  clickback(){
    wx.navigateBack({ delta: 1});
  },
  openadv(){
    if (rewardedVideoAd) {
      wx.showLoading({title: '视频加载中'})
      rewardedVideoAd.show().catch(() => {
          rewardedVideoAd.load()
          .then(() => rewardedVideoAd.show())
          .catch(err => {
            wx.showToast({
              title: "视频加载失败",
              duration: 2000,
              icon: 'error'
            })
          }).finally(() => {
            wx.hideLoading()
          })
      }).finally(() => {
        wx.hideLoading()
      })
    }else{
      wx.showToast({
        title: "视频加载失败",
        duration: 2000,
        icon: 'error'
      })
    }
  },
  saveviprecord(){
    var self = this;
    wx.request({
      url: app.globalData.baseUrl + "wechatspecial/wxminiprogram/setviprecord",
      data: {hdid:app.globalData.hdid,openid: app.globalData.openid,user:self.data.user},
      method:'POST',
      header: {'content-type': 'application/json'},
      success: function(res) {
        if(res.data.code=='0'){
          self.setData({endtime:res.data.msg});
          app.globalData.adendtime = res.data.msg;
          self.startDjs()
        }else{
          wx.showToast({
            title: res.data.msg||"网络异常",
            duration: 2000,
            icon: 'error'
          })
        }
      },
      fail: function() {
          wx.showToast({
            title: '网络异常',
            duration: 2000,
            icon: 'error'
          })
      }
    })
  },
  startDjs(type){
    type = type || '2'
    this.clearDjs()
    if(type == '1'){
      let obj = this.getTimeLeft()
      if(obj != 0){
        this.setData({timeLeft: {h: obj.h,m: obj.m,s: obj.s}});
      }
    }
    timer = setInterval(() => { 
      let leftobj = this.getTimeLeft()
      if (leftobj === 0) {
        clearInterval(timer);
        this.setData({timeLeft: {h: '00',m: '00',s: '00'},endtime:0});
        app.globalData.adendtime = 0;
      }else{
        this.setData({timeLeft: leftobj});
      }
    }, 1e3);
  },
  clearDjs(){
    if(timer){
      clearInterval(timer);
    }
  },
  getTimeLeft() {
    var now = new Date().getTime();
    var end = +new Date(this.data.endtime * 1000);
    var lefttime = end - now;
    var h, m, s;
    if (lefttime >= 0) {
        h = Math.floor(lefttime / 1000 / 60 / 60);
        m = Math.floor(lefttime / 1000 / 60 % 60);
        s = Math.floor(lefttime / 1000 % 60);
        h = h < 10 ? ("0" + h) : h;
        m = m < 10 ? ("0" + m) : m;
        s = s < 10 ? ("0" + s) : s;
        return {h:h,m:m,s:s}
    } 
    return 0
  }
})
 
 
 