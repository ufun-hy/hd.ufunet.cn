//index.js
const app = getApp()
let interstitialAd = null
let adtimer = null
Page({
  data: {url:''},
  onLoad: function(options) {
    var self = this;
    var shareid = options.userid||'';
    if (options.scene !== undefined){
      app.globalData.scene = decodeURIComponent(options.scene);
    }else{
      try {
        var value = wx.getStorageSync('sceneval')
        if (value) {
          app.globalData.scene = decodeURIComponent(value);
        }
      } catch (e) {}
    }
    wx.showLoading({
      title: '活动加载信息中..',
    })
    self.gethuodongInfo(function(){
      if (wx.createInterstitialAd && app.globalData.adid!='') {
        interstitialAd = wx.createInterstitialAd({adUnitId: app.globalData.adid })
        interstitialAd.onLoad(() => {})
        interstitialAd.onError((err) => {console.log(err);})
        interstitialAd.onClose(() => {})
      }
      var url = `${app.globalData.baseUrl}wechat/${app.globalData.module}/${app.globalData.action}?hdid=${app.globalData.hdid}&wxminiopenid=${app.globalData.openid}`;
      if(shareid){
        url += `&shareid=${shareid}`;
      }
      if(app.globalData.channelstr != ''){
         url += `&channelstr=${app.globalData.channelstr}`;
      }
      self.setData({url: url});
      if(app.globalData.scene != ''){
        try {
          wx.setStorageSync('sceneval', app.globalData.scene)
        } catch (e) {}
      }
    });
  },
  gethuodongInfo(callback){
    wx.request({
      url: app.globalData.baseUrl + "wechatspecial/wxminiprogram/index",
      data: {scene:app.globalData.scene},
      method:'POST',
      header: {'content-type': 'application/json'},
      success: function(res) {
        wx.hideLoading()
        if(res.data.code=='0'){
          app.globalData.scene = res.data.msg.sceneid || '';
          app.globalData.hdid = res.data.msg.hdid;
          app.globalData.channelstr = res.data.msg.channelstr || '';
          app.globalData.module = res.data.msg.module;
          app.globalData.action = res.data.msg.action;
          app.globalData.adid = res.data.msg.adid || '';
          app.globalData.adtimeout = res.data.msg.adtimeout;
          app.globalData.rewardedadid = res.data.msg.rewardedadid||'';
          app.globalData.rewardhour = res.data.msg.rewardhour;
          app.globalData.sharedata = res.data.msg.sharedata;
          var shareopen = app.globalData.sharedata.open||'2';
          if(shareopen == '2'){
            wx.hideShareMenu();
          }
          app.getUserOpenId(function(){
            app.getViprecord(function(endtime){
              app.globalData.adendtime = endtime;
              callback()
            })
          });
        }else{
          wx.showToast({
            title: res.data.msg||"加载出现异常",
            duration: 4000,
            icon: 'error'
          })
        }
      },
      fail: function() {
        wx.hideLoading()
        wx.showToast({
          title: '获取活动信息失败',
          duration: 2000,
          icon: 'error'
        })
      }
    })
  },
  bindload: function (e) {
    var now = new Date().getTime();
    var end = +new Date(app.globalData.adendtime * 1000);
    if (interstitialAd && end - now < 0 ) {
	    if(adtimer) {
        clearTimeout(adtimer)
      }
      adtimer = setTimeout(()=>{
        interstitialAd.show().catch((err) => {
          console.log(err)
        })
      },app.globalData.adtimeout||16e3)
    }
  },
  onShareAppMessage(options) {
    //console.log(options.webViewUrl);
    const promise = new Promise(resolve => {
      wx.request({
        url: app.globalData.baseUrl + "wechatspecial/wxminiprogram/getshareid",
        data: {hdid:app.globalData.hdid,openid: app.globalData.openid},
        method:'POST',
        success(res) {
          if(res.data.code=='0'){
            app.globalData.uid = res.data.msg;
      		//需要通过请求服务器获取参数时
            resolve({
              title:app.globalData.sharedata.title,
              imageUrl: app.globalData.sharedata.icon,
              path:`pages/index/index?scene=${app.globalData.scene}&userid=${res.data.msg}`
            })
          }
        }})
    });
    //3秒内如请求中的resolve未执行，则执行以下代码
    return {
      title:app.globalData.sharedata.title,
      imageUrl: app.globalData.sharedata.icon,
      path: `pages/index/index?scene=${app.globalData.scene}`,
      promise
    }
  },

  onShareTimeline() {
    return {};
  }
})
