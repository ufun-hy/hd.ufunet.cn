// pages/subnotice/index.js
const app = getApp()
Page({
  data: {
    user: {
      userid:'',
      openid: '',
      tplid: '',
    },
  },
  onLoad(options) {
    const self = this
    if(options){
      let params = decodeURIComponent(options.params||'');
      if(params){
        params = JSON.parse(params) || {}
        if(params.userid && params.openid){
          self.setData({user:params});
        }
      }
    }
    wx.hideShareMenu();
    wx.setNavigationBarTitle({title: "订阅中奖通知"});
  },
  subnotice() {
    const self = this
    //这里通过ajax去获取模板id还是通过params来得到模板id好呢
    wx.requestSubscribeMessage({
      tmplIds: [self.data.user.tplid],
      success (res) { 
          //'accept'、'reject'、'ban'、'filter'
          const status = res[self.data.user.tplid]||'';
          if(status == 'accept'){
            wx.request({
              url: app.globalData.baseUrl + "wechatspecial/wxminiprogram/confirmsubnotice",
              data: Object.assign({},self.data.user,{
                hdid: app.globalData.hdid,
                wxminiopenid: app.globalData.openid,
              }),
              method:'POST',
              header: {'content-type': 'application/json'},
              success: function(result) {
                if(result.data.code == 0){
                    self.clickback();
                }else{
                    wx.showToast({
                      title: '订阅失败，'+(result.data.msg||""),
                      duration: 4000,
                      icon: 'error',
                    })
                }
              },
              fail: function(err) {
                  wx.showToast({
                    title: '订阅出现异常',
                    duration: 4000,
                    icon: 'error',
                  })
              }
            });
          }else if(status == 'reject'){
            self.guideOpenSubscribeMessage();
          }else if(status == 'ban'){
            wx.showToast({
              title: '模板已被封禁',
              duration: 2000,
              icon: 'error'
            })
          }else{
            wx.showToast({
              title: '出现异常',
              duration: 2000,
              icon: 'error'
            })
          }
      },
      fail(res) { 
        if (res.errCode == 20004) {
          self.guideOpenSubscribeMessage();
        }else{
          wx.showToast({
            title: res.errMsg,
            duration: 2000,
            icon: 'error'
          })
        }
       
      },
    })
  },
  guideOpenSubscribeMessage(){
    wx.showModal({
      title: '提示',
      content: '为了提供更好的服务，请将小程序订阅消息以及中奖结果通知设置为接收',
      showCancel: false,
      confirmText: '去设置',
      success: function(res) {
        if (res.confirm) {
          wx.openSetting();
        }
      }
    });
  },
  clickback(){
    wx.navigateBack({ delta: 1});
  },
})