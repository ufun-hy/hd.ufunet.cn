// pages/phone/index.js
const app = getApp()
Page({
  data: {
    success: '2',
    user: {
      type: '1',
      userid:'',
      openid: '',
      hdid:'',
    },
  },
  onLoad(options) {
    const self = this
    let params = decodeURIComponent(options.params||'');
    if(params){
      params = JSON.parse(params) || {}
      if(params.userid && params.openid){
        self.setData({user:params});
      }
    }
    wx.hideShareMenu();
    wx.setNavigationBarTitle({title: "授权获取您的微信手机号"});
  },
  getPhoneNumber(e) {
    const self = this
    if (e.detail.errMsg === "getPhoneNumber:ok") {
        app.getPhoneNumber({
          code:e.detail.code,
          user: self.data.user
        },function(){
          var type = self.data.user.type || '1';
          if(type == '1'){
            self.clickback();
          }else{
            self.setData({success: '1'});
          }
        });
    } else{
      wx.showToast({
        title: '您选择了不允许获取手机号',
        duration: 4000,
        icon: 'error'
      })
    }
  },
  clickback(){
    wx.navigateBack({ delta: 1});
  },
})