const app = getApp()
Page({
  onLoad: function(options) {
    const self = this
    wx.hideShareMenu();
    wx.setNavigationBarTitle({
      title: "微信支付"
    })
    let orderdata = JSON.parse(decodeURIComponent(options.orderdata));
    app.getUserOpenId(function(openid){
            orderdata.openid = openid;
            wx.request({
              url: app.globalData.baseUrl + "wechatspecial/wxminiprogram/wxpay",
              data: orderdata,
              method:'POST',
              header: {'content-type': 'application/json'},
              success: function(result) {
                if(result.data.code==0){
                    var payData = result.data.msg;
                    wx.requestPayment({
                        timeStamp: ""+payData.timestamp,
                        nonceStr: payData.nonceStr,
                        package: payData.package, 
                        signType: payData.signType,
                        paySign:payData.paySign,
                        success: function (res) {
                          wx.showToast({
                            title: '支付成功',
                            icon: 'success',
                            duration: 2000,
                            success:function(){
                              setTimeout(function () {
                                wx.navigateBack({  delta: 1});
                              },2000);
                            }
                          })     
                        },
                        fail: function(err) {
                          if (err.errMsg.indexOf("fail cancel")!=-1){
                            wx.showToast({
                              title: '您已取消支付',
                              icon: 'error',
                              duration: 2000,
                              success:function(){
                                setTimeout(function () {
                                  wx.navigateBack({  delta: 1});
                                },2000);
                              }
                            })
                          }else{
                            wx.showToast({
                              title: err.errMsg,
                              duration: 4000,
                              icon: 'error',
                              success:function(){
                                setTimeout(function () {
                                  wx.navigateBack({  delta: 1});
                                },4000);
                              }
                            })
                          }
                        },
                    })
                }else{
                    wx.showToast({
                      title: '发起支付失败'+(result.data.msg||""),
                      duration: 4000,
                      icon: 'error',
                      success:function(){
                        setTimeout(function () {
                          wx.navigateBack({  delta: 1});
                        },4000);
                      }
                    })
                }
            },
            fail: function(err) {
                wx.showToast({
                  title: '发起微信支付失败'+(err.errMsg||""),
                  duration: 4000,
                  icon: 'error',
                  success:function(){
                    setTimeout(function () {
                      wx.navigateBack({  delta: 1});
                    },100);
                  }
                })
            }
          })
    });
  }
})
 
 
 