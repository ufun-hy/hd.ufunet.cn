// pages/oauth/index.js
const app = getApp()
Page({
  data: {url:''},
  onLoad(options) {
    wx.hideShareMenu();
    var self = this;
    var params = options.params||'';
    if(params==''){
      wx.showToast({
        title: '参数异常',
        duration: 2000,
        icon: 'error',
      });
    }else{
      self.setData({
        url: `${app.globalData.baseUrl}wechatspecial/wxminiprogram/oauth?params=${params}`,
      });
    }

  },
})