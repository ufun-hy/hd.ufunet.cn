//app.js
App({
  onLaunch: function () {
    this.globalData = {
      scene:'',
      openid:null,
      hdid:'',
      channelstr: '',
      module:'index',
      action:'index',
      adid:'',
      adtimeout:16000,
      adendtime:0,
      rewardedadid:'',
      rewardhour:24,
      baseUrl:'https://您的域名/',
      sharedata:{
        open:'2',
        title:'好玩的互动平台',
        desc: '快来体验下',
        icon: '',
      },
      uid:'',
    }
  },
  getUserOpenId(callback) {
    const self = this
    if (self.globalData.openid) {
      callback(self.globalData.openid)
    } else {
      wx.login({
        success(data) {
          if (data.code) {
            wx.request({
              url: self.globalData.baseUrl + "wechatspecial/wxminiprogram/codetopenid",
              data: {code: data.code},
              method:'POST',
              header: {'content-type': 'application/json'},
              success: function(res) {
                if(res.data.code=='0'){
                    self.globalData.openid = res.data.msg.openid;
                    callback(self.globalData.openid)
                }else{
                    wx.showToast({
                      title: '获取openid失败' + (res.data.msg||""),
                      duration: 2000,
                      icon: 'error',
                      success:function(){
                        setTimeout(function () {
                          wx.navigateBack({  delta: 1});
                        },2000);
                      },
                    })
                }
              },
              fail: function() {
                  wx.showToast({
                    title: '获取openid失败',
                    duration: 2000,
                    icon: 'error',
                    success:function(){
                      setTimeout(function () {
                        wx.navigateBack({  delta: 1});
                      },2000);
                    },
                  })
              }
            })
          }else{
              wx.showToast({
                title: '获取openid失败',
                duration: 2000,
                icon: 'error',
                success:function(){
                  setTimeout(function () {
                    wx.navigateBack({  delta: 1});
                  },2000);
                },
              })
          }
        },
        fail(err) {
          wx.showToast({
            title: '获取openid失败',
            duration: 2000,
            icon: 'error',
            success:function(){
              setTimeout(function () {
                wx.navigateBack({  delta: 1});
              },2000);
            },
          })
        }
      })
    }
  },
  getViprecord(callback){
    var self = this;
    wx.request({
      url: self.globalData.baseUrl + "wechatspecial/wxminiprogram/getviprecord",
      data: {hdid:self.globalData.hdid,openid: self.globalData.openid},
      method:'POST',
      header: {'content-type': 'application/json'},
      success: function(res) {
        wx.hideLoading()
        if(res.data.code=='0'){
          callback(res.data.msg)
        }else{
          wx.showToast({
            title: res.data.msg||"获取观看记录出现异常",
            duration: 4000,
            icon: 'error'
          })
        }
      },
      fail: function() {
        wx.hideLoading()
        wx.showToast({
          title: '获取观看记录失败',
          duration: 2000,
          icon: 'error'
        })
      }
    })
  },
  getPhoneNumber(paras,callback){
    var self = this;
    wx.request({
      url: self.globalData.baseUrl + "wechatspecial/wxminiprogram/getphonenum",
      data: {hdid:self.globalData.hdid,user:paras.user,code:paras.code},
      method:'POST',
      header: {'content-type': 'application/json'},
      success: function(res) {
        wx.hideLoading()
        if(res.data.code=='0'){
          callback(res.data.msg)
        }else{
          wx.showToast({
            title: res.data.msg||'获取手机号出现异常',
            duration: 4000,
            icon: 'error'
          })
        }
      },
      fail: function() {
        wx.hideLoading()
        wx.showToast({
          title: '获取手机号出现异常',
          duration: 2000,
          icon: 'error'
        })
      }
    })
  },
})
